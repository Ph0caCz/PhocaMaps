ALTER TABLE `#__phocamaps_map` CHANGE `width` `width` VARCHAR(50) NOT NULL DEFAULT '';
ALTER TABLE `#__phocamaps_map` CHANGE `height` `height` VARCHAR(50) NOT NULL DEFAULT '';

